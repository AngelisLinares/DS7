<?php
    $host = "localhost";
    $user = "root";
    $clave = ""; // Asegúrate de que esta sea la contraseña correcta
    $bd = "bdds7";
    $puerto = 3307; // Especifica el puerto 3307

    $conexion = mysqli_connect($host, $user, $clave, $bd, $puerto);
    
    if (mysqli_connect_errno()) {
        echo "No se pudo conectar a la base de datos: " . mysqli_connect_error();
        exit();
    }

    mysqli_select_db($conexion, $bd) or die("No se encuentra la base de datos");
    mysqli_set_charset($conexion, "utf8");
?> 
