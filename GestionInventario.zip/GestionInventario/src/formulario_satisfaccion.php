<?php
session_start();
include 'php/db_connection.php';


// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id_paciente'])) {
    header("Location: index.php"); // Redirigir al inicio de sesión si no está autenticado
    exit();
}

$id_paciente = $_SESSION['id_paciente'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Satisfacción</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h3>Formulario de Satisfacción</h3>

        <!-- Mensaje de confirmación de cita -->
        <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success mt-3">¡Cita agendada correctamente! Por favor, completa nuestro formulario de satisfacción.</div>
        <?php endif; ?>

        <form action="procesar_satisfaccion.php" method="post">
            <div class="mb-3">
                <label for="puntuacion" class="form-label">¿Qué tan satisfecho estás con el servicio? (1-5)</label>
                <select name="puntuacion" id="puntuacion" class="form-control" required>
                    <option value="">Selecciona una opción</option>
                    <option value="1">1 - Muy insatisfecho</option>
                    <option value="2">2 - Insatisfecho</option>
                    <option value="3">3 - Neutral</option>
                    <option value="4">4 - Satisfecho</option>
                    <option value="5">5 - Muy satisfecho</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="comentarios" class="form-label">Comentarios adicionales</label>
                <textarea name="comentarios" id="comentarios" class="form-control" placeholder="Escribe tus comentarios aquí..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
</body>
</html>
