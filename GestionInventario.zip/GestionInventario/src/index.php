<?php
require "../conexion.php";
$usuarios = mysqli_query($conexion, "SELECT * FROM usuario");
$total['usuarios'] = mysqli_num_rows($usuarios);
$clientes = mysqli_query($conexion, "SELECT * FROM cliente");
$total['clientes'] = mysqli_num_rows($clientes);
$productos = mysqli_query($conexion, "SELECT * FROM producto");
$total['productos'] = mysqli_num_rows($productos);
$ventas = mysqli_query($conexion, "SELECT * FROM ventas WHERE fecha > CURDATE()");
$total['ventas'] = mysqli_num_rows($ventas);
session_start();
include_once "includes/header.php";
?>

<!-- Content Row -->
<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
        <div class="card border-0 shadow">
            <div class="card-header bg-primary text-white text-center">
                <i class="fas fa-user fa-2x"></i>
                <h4 class="mt-2">Usuarios</h4>
            </div>
            <div class="card-body text-center">
                <h3 class="card-title"><?php echo $total['usuarios']; ?></h3>
            </div>
            <a href="usuarios.php" class="card-footer text-primary text-center bg-light">Ver Detalles</a>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
        <div class="card border-0 shadow">
            <div class="card-header bg-success text-white text-center">
                <i class="fas fa-users fa-2x"></i>
                <h4 class="mt-2">Clientes</h4>
            </div>
            <div class="card-body text-center">
                <h3 class="card-title"><?php echo $total['clientes']; ?></h3>
            </div>
            <a href="clientes.php" class="card-footer text-success text-center bg-light">Ver Detalles</a>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
        <div class="card border-0 shadow">
            <div class="card-header bg-danger text-white text-center">
                <i class="fab fa-product-hunt fa-2x"></i>
                <h4 class="mt-2">Productos</h4>
            </div>
            <div class="card-body text-center">
                <h3 class="card-title"><?php echo $total['productos']; ?></h3>
            </div>
            <a href="productos.php" class="card-footer text-danger text-center bg-light">Ver Detalles</a>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
        <div class="card border-0 shadow">
            <div class="card-header bg-info text-white text-center">
                <i class="fas fa-cash-register fa-2x"></i>
                <h4 class="mt-2">Ventas</h4>
            </div>
            <div class="card-body text-center">
                <h3 class="card-title"><?php echo $total['ventas']; ?></h3>
            </div>
            <a href="ventas.php" class="card-footer text-info text-center bg-light">Ver Detalles</a>
        </div>
    </div>

    <!-- Products Expired Table -->
    <div class="col-12">
        <div class="card shadow border-0 mb-4">
            <div class="card-header bg-primary text-white">
                <h4>Productos Vencidos</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Código</th>
                                <th>Producto</th>
                                <th>Tipo</th>
                                <th>Presentación</th>
                                <th>Precio</th>
                                <th>Stock</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include "../conexion.php";
                            $hoy = date('Y-m-d');
                            $query = mysqli_query($conexion, "SELECT p.*, t.tipo, pr.nombre FROM producto p INNER JOIN tipos t ON p.id_tipo = t.id INNER JOIN presentacion pr ON p.id_presentacion = pr.id WHERE p.vencimiento != '0000-00-00' AND p.vencimiento < '$hoy'");
                            $result = mysqli_num_rows($query);
                            if ($result > 0) {
                                while ($data = mysqli_fetch_assoc($query)) { ?>
                                    <tr>
                                        <td><?php echo $data['codproducto']; ?></td>
                                        <td><?php echo $data['codigo']; ?></td>
                                        <td><?php echo $data['descripcion']; ?></td>
                                        <td><?php echo $data['tipo']; ?></td>
                                        <td><?php echo $data['nombre']; ?></td>
                                        <td><?php echo $data['precio']; ?></td>
                                        <td><?php echo $data['existencia']; ?></td>
                                        <td>
                                            <form action="eliminar_producto.php?id=<?php echo $data['codproducto']; ?>" method="post" class="confirmar d-inline">
                                                <button class="btn btn-danger btn-sm" type="submit"><i class='fas fa-trash-alt'></i></button>
                                            </form>
                                        </td>
                                    </tr>
                            <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Stock and Sales Charts -->
    <div class="col-lg-6 mb-4">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white">
                <h4>Productos con Stock Mínimo</h4>
            </div>
            <div class="card-body">
                <canvas id="stockMinimo"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6 mb-4">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white">
                <h4>Productos Más Vendidos</h4>
            </div>
            <div class="card-body">
                <canvas id="ProductosVendidos"></canvas>
            </div>
        </div>
    </div>
</div>

<?php include_once "includes/footer.php"; ?>
