<?php 
require '../conexion.php';  // Conexión a la base de datos

// Verificar si el token está presente en la URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Buscar el token en la base de datos
    $stmt = $conexion->prepare("SELECT id_paciente, token_expiry FROM pacientes WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $current_time = date('Y-m-d H:i:s');

        // Verificar si el token ha expirado
        if ($row['token_expiry'] > $current_time) {
            // Token válido, mostrar el formulario para restablecer la contraseña
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

                // Actualizar la contraseña en la base de datos
                $updateStmt = $conexion->prepare("UPDATE pacientes SET pass = ?, reset_token = NULL, token_expiry = NULL WHERE reset_token = ?");
                $updateStmt->bind_param("ss", $new_password, $token);
                $updateStmt->execute();

                // Verificar si la actualización fue exitosa
                if ($updateStmt->affected_rows > 0) {
                    echo "Contraseña restablecida exitosamente.";
                } else {
                    echo "Hubo un error al restablecer la contraseña. Por favor, intenta nuevamente.";
                }
            }
            ?>

<div class="container mt-5">
        <h2 class="text-center">Restablecer Contraseña</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="new_password">Nueva Contraseña:</label>
                <input type="password" class="form-control" name="new_password" id="new_password" placeholder="Ingresa tu nueva contraseña" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirmar Nueva Contraseña:</label>
                <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirma tu nueva contraseña" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Restablecer Contraseña</button>
            </div>
        </form>
    </div>



            <?php
        } else {
            echo "El enlace ha expirado. Por favor, solicita uno nuevo.";
        }
    } else {
        echo "El token no es válido. Por favor, verifica el enlace.";
    }
} else {
    echo "No se proporcionó un token.";
}
?>

