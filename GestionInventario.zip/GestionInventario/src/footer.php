<footer class="bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="text-center p-3">
                © 2024 MiSalud | Política de privacidad | Términos de servicio | 
                             Integrantes: Joel Castillo 8-989-1455
                            Erick Mendez 8-970-940
                         Angelina Linares 8-977-1369
                        Irving Camarena 8-988-383
                </a>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS (necesario para algunos componentes de Bootstrap) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
