<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Inicio - mi salud</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/navbar.css" rel="stylesheet">
    <!-- Enlace a Font Awesome (inclusión en el head) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>
<body>
    <!-- Sección de Navegación -->
    <section class="navbar-section">
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container-fluid">
            <!-- Logo de la página -->
            <img src="../assets/img/Logo2.jfif" alt="MiSalud" class="d-block" style="height: 175px;">

            <!-- Botón de navegación para dispositivos pequeños -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Menú de navegación -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-home"></i> Inicio
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-pills"></i> Farmacia
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="solicitar_cita.php">
                            <i class="fas fa-calendar-check"></i> Solicitar Citas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="perfil.php">
                            <i class="fas fa-user"></i> Perfil
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../src/login.php">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</section>
<!-- Slider Section -->
<section id="slider" class="py-5">
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <!-- Indicadores -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>

        <!-- Contenido del slider -->
        <div class="carousel-inner">
            <!-- Imagen 1 -->
            <div class="carousel-item active">
                <img src="../assets/img/Hospital.jpg" class="d-block mx-auto" style="height: 600px; width: 100%;" alt="Imagen 1">
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="fw-bold">Bienvenido al Hospital MiSalud</h5>
                    <p>Excelencia en atención médica desde 2001.</p>
                </div>
            </div>
            <!-- Imagen 2 -->
            <div class="carousel-item">
            <img src="../assets/img/hospitales_inteligentes.jpg" class="d-block mx-auto" style="height: 600px; width: 100%;" alt="Imagen Mediana">

                <!--<img src="../assets/img/logo.png" class="d-block w-100" alt="Imagen 2"> -->
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="fw-bold">Tecnología de Vanguardia</h5>
                    <p>Equipos modernos para diagnóstico y tratamiento avanzado.</p>
                </div>
            </div>
            <!-- Imagen 3 -->
            <div class="carousel-item">
                <img src="../assets/img/Especialidad.jpeg" class="d-block mx-auto" style="height: 600px; width: 100%;" alt="Imagen 3">
                <div class="carousel-caption d-none d-md-block">
                    <h5 class="fw-bold">Especialistas de Renombre</h5>
                    <p>Cuidado personalizado por profesionales de prestigio.</p>
                </div>
            </div>
        </div>

        <!-- Controles de navegación -->
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Anterior</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Siguiente</span>
        </button>
    </div>
</section>

    <!-- Sección de Servicios Médicos -->
    <section class="py-5">
    <div class="container">
        <h2 class="text-center mb-5">Nuestros Servicios</h2>
        <div class="row">
            <div class="col-lg-4 text-center">
                <img src="../assets/img/emergencia1.png" alt="emergencia" class="rounded-circle mb-1" style="width: 250px; height: 250px;">
                <h3>Emergencias 24/7</h3>
                <p>Atención médica de urgencias y emergencias disponible las 24 horas del día, los 7 días de la semana.</p>
            </div>
            <div class="col-lg-4 text-center">
                <img src="../assets/img/emergencia.png" alt="Servicio 2" class="rounded-circle mb-3" style="width: 250px; height: 250px;">
                <h3>Especialidades Médicas</h3>
                <p>Ofrecemos una amplia gama de especialidades médicas con profesionales de renombre nacional e internacional.</p>
            </div>
            <div class="col-lg-4 text-center">
                <img src="../assets/img/Diagnostico.png" alt="Servicio 3" class="rounded-circle mb-3" style="width: 250px; height: 250px;">
                <h3>Diagnóstico Avanzado</h3>
                <p>Contamos con la última tecnología en equipos de diagnóstico y tratamiento para asegurar una atención de calidad.</p>
            </div>
        </div>
    </div>
</section>



    <!-- Sección de Noticias o Actualizaciones -->
    <section class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Noticias y Actualizaciones</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/350x150" class="card-img-top" alt="Noticia 1">
                        <div class="card-body">
                            <h5 class="card-title">Nuevo Centro de Oncología</h5>
                            <p class="card-text">El Hospital MiSalud inaugura un nuevo centro de oncología con tecnología avanzada para el tratamiento del cáncer.</p>
                            <a href="#" class="btn btn-primary">Leer más</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/350x150" class="card-img-top" alt="Noticia 2">
                        <div class="card-body">
                            <h5 class="card-title">Nueva Área de Pediatría</h5>
                            <p class="card-text">Hemos renovado nuestra área de pediatría para ofrecer mayor confort y seguridad a nuestros pacientes más pequeños.</p>
                            <a href="#" class="btn btn-primary">Leer más</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://via.placeholder.com/350x150" class="card-img-top" alt="Noticia 3">
                        <div class="card-body">
                            <h5 class="card-title">Certificación Internacional</h5>
                            <p class="card-text">El Hospital Paitilla recibe una nueva certificación internacional por la calidad de sus servicios médicos.</p>
                            <a href="#" class="btn btn-primary">Leer más</a>
                        </div>
                    </div>
                </div>
            </div>


    <!-- Footer -->
    <?php include('footer.php'); ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
