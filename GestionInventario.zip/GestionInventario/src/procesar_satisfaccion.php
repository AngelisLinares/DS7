<?php
session_start();
include 'php/db_connection.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id_paciente'])) {
    header("Location: index.php"); // Redirige al inicio de sesión si no está autenticado
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_paciente = $_SESSION['id_paciente'];
    $puntuacion = $_POST['puntuacion'];
    $comentarios = $_POST['comentarios'];

    // Insertar los datos en la tabla satisfaccion
    $stmt = $conn->prepare("INSERT INTO satisfaccion (id_paciente, puntuacion, comentarios) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $id_paciente, $puntuacion, $comentarios);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Redirigir al inicio después de completar el formulario de satisfacción
        header("Location: inicio.php");
        exit();
    } else {
        echo "Error al guardar la satisfacción: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>