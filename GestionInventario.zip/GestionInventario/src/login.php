<?php
session_start();
if (!empty($_SESSION['active'])) {
    header('location: src/');
} else {
    if (!empty($_POST)) {
        $alert = '';
        if (empty($_POST['usuario']) || empty($_POST['clave'])) {
            $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                        Ingrese usuario y contraseña
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>';
        } else {
            include "../conexion.php";
            $user = mysqli_real_escape_string($conexion, $_POST['usuario']);
            $clave = md5(mysqli_real_escape_string($conexion, $_POST['clave']));
            $query = mysqli_query($conexion, "SELECT * FROM usuario WHERE usuario = '$user' AND clave = '$clave'");
            mysqli_close($conexion);
            $resultado = mysqli_num_rows($query);
            if ($resultado > 0) {
                $dato = mysqli_fetch_array($query);
                $_SESSION['active'] = true;
                $_SESSION['idUser'] = $dato['idusuario'];
                $_SESSION['nombre'] = $dato['nombre'];
                $_SESSION['user'] = $dato['usuario'];
                header('Location: src/inicio.php');
            } else {
                $alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        Contraseña incorrecta
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>';
                session_destroy();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="assets/img/favicon.ico" />
</head>
<body class="bg-primary d-flex align-items-center" style="min-height: 100vh;">
    <div class="container">
        <div class="col-md-4 mx-auto">
            <?php echo (isset($alert)) ? $alert : ''; ?>
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white text-center">
                    <img src="../assets/img/Logo.jfif" alt="Logo" class="mb-3" style="width: 80px;">
                    <h4 class="card-title text-primary">Iniciar Sesión</h4>
                </div>
                <div class="card-body">
                    <?php echo isset($alert) ? $alert : ''; ?>
                    <form action="" method="post" class="p-3">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-lg text-center" placeholder="Usuario" name="usuario" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg text-center" placeholder="Clave" name="clave" required>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-primary btn-block btn-lg font-weight-medium" type="submit">Login</button>
                        </div>

                        <p class="text-center mt-3">
          ¿No tienes una cuenta? <a href="src/registro.php">Registrate</a>
          <br>
          Olvidaste la contraseña? <a href="src/contrasena.php"> Recuperar </a>
        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
