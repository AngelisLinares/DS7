<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

require '../src/PHPMailer/Exception.php';
require '../src/PHPMailer/PHPMailer.php';
require '../src/PHPMailer/SMTP.php';
require_once '../conexion.php'; // Asegúrate de que este archivo usa MySQLi para la conexión

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validar si el correo está definido
    if (!isset($_POST['email'])) {
        die("Error: No se proporcionó un correo electrónico.");
    }

    // Sanitizar el correo electrónico
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Verificar si la conexión a la base de datos está establecida
    if (!$conexion || $conexion->connect_error) {
        die("Error: No se pudo establecer la conexión a la base de datos.");
    }

    try {
        // Verificar si el correo existe en la base de datos
        $stmt = $conexion->prepare("SELECT id_paciente FROM pacientes WHERE email = ?");
        $stmt->bind_param("s", $email); // Vincular el parámetro
        $stmt->execute();
        $result = $stmt->get_result(); // Obtener el resultado

        if ($result->num_rows > 0) {
            // Usuario encontrado, generar token único
            $token = bin2hex(random_bytes(32));
            $token_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Actualizar el token en la base de datos
            $updateStmt = $conexion->prepare("UPDATE pacientes SET reset_token = ?, token_expiry = ? WHERE email = ?");
            $updateStmt->bind_param("sss", $token, $token_expiry, $email);
            $updateStmt->execute();

            // Crear el enlace de recuperación
            $resetLink = "http://localhost/GestionInventario/src/reset_password.php?token=" . $token;

            // Enviar correo con PHPMailer
            $mail = new PHPMailer(true);

            try {
                // Configuración del servidor SMTP
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Cambia esto por tu servidor SMTP
                $mail->SMTPAuth = true;
                $mail->Username = 'eamj150301@gmail.com'; // Tu correo electrónico
                $mail->Password = 'wboa rrmf qcgr gnoz'; // Tu contraseña
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587; // Puerto SMTP

                // Configuración del correo
                $mail->setFrom('eamj150301@gmail.com', 'Mi Salud'); // Remitente
                $mail->addAddress($email); // Destinatario

                $mail->isHTML(true);
                $mail->Subject = 'Recuperación de Contraseña';
                $mail->Body = "
                    <p>Hola,</p>
                    <p>Has solicitado restablecer tu contraseña. Por favor, haz clic en el enlace a continuación para continuar:</p>
                    <p><a href='$resetLink'>$resetLink</a></p>
                    <p>Este enlace expirará en 1 hora.</p>
                    <p>Si no solicitaste este cambio, ignora este correo.</p>
                    <p>Saludos,<br>Mi Salud</p>
                ";

                // Enviar el correo
                $mail->send();
                $message = "<div class='alert alert-success'>Se ha enviado un enlace de recuperación a tu correo electrónico.</div>";
            } catch (Exception $e) {
                $message = "<div class='alert alert-danger'>No se pudo enviar el correo. Error: {$mail->ErrorInfo}</div>";
            }

        } else {
            $message = "<div class='alert alert-danger'>No se encontró ninguna cuenta con ese correo electrónico.</div>";
        }

        // Cerrar las declaraciones
        $stmt->close();
        if (isset($updateStmt)) $updateStmt->close();

    } catch (Exception $e) {
        $message = "<div class='alert alert-danger'>Error en el sistema. Por favor, intenta más tarde.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .recover-form {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="recover-form">
            <h2 class="text-center mb-4">Recuperar Contraseña</h2>
            
            <?php if($message) echo $message; ?>
            
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="email" class="form-label">Correo Electrónico</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Enviar Link de Recuperación</button>
                </div>
                <div class="text-center mt-3">
                    <a href="index.php">Volver al inicio de sesión</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>